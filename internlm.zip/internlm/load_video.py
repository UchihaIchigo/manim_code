import torch
import os
import cv2
from PIL import Image
# torch.cuda.set_device(1)  # 选择第二个GPU
os.environ['CUDA_VISIBLE_DEVICES']='1' #此处选择你要用的GPU序号 0，1，2，3
os.environ['CUDA_LAUNCH_BLOCKING'] = '1' # 下面老是报错 shape 不一致
os.environ['TORCH_USE_CUDA_DSA'] = '1'
from transformers import AutoTokenizer, AutoModelForCausalLM
ckpt_path = "internlm/internlm-xcomposer2-vl-7b"
tokenizer = AutoTokenizer.from_pretrained(ckpt_path, trust_remote_code=True, cache_dir="/data/internlm-explore/models")
# Set `torch_dtype=torch.float16` to load model in float16, otherwise it will be loaded as float32 and might cause OOM Error.
model = AutoModelForCausalLM.from_pretrained(ckpt_path, torch_dtype=torch.float32, trust_remote_code=True, cache_dir="/data/internlm-explore/models").cuda()
model = model.eval()
# 视频路径
video_path = '/data/internlm-explore/11.mp4'

# 视频帧提取函数
# 提取视频帧的函数
# 提取视频帧的函数
def extract_frames(video_path, frame_rate=1):
    cap = cv2.VideoCapture(video_path)
    frames = []
    success, frame = cap.read()
    count = 0
    while success:
        if count % frame_rate == 0:
            frames.append(frame)
        success, frame = cap.read()
        count += 1
    cap.release()
    return frames

# 帧处理函数
def process_frames(frames, model):
    processed_frames = []
    for frame in frames:
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        img_tensor = model.vis_processor(img).unsqueeze(0).cuda()
        processed_frames.append(img_tensor)
    return processed_frames



# 提取和处理视频帧
frames = extract_frames(video_path, frame_rate=1)  # 每30帧提取一个帧
processed_frames = process_frames(frames, model)

# 将处理后的帧拼接为一个张量
images_tensor = torch.cat(processed_frames, dim=0)

# 模型推理
query = "Describe the video content <ImageHere>"
history = []
meta_instruction = ""

# 使用模型进行推理
response, history = model.chat(
    tokenizer=tokenizer,
    query=query,
    image=images_tensor,
    history=history,
    meta_instruction=meta_instruction
)

print(response)
