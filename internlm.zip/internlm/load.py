import torch
import os
# torch.cuda.set_device(1)  # 选择第二个GPU
os.environ['CUDA_VISIBLE_DEVICES']='1' #此处选择你要用的GPU序号 0，1，2，3
os.environ['CUDA_LAUNCH_BLOCKING'] = '1' # 下面老是报错 shape 不一致
os.environ['TORCH_USE_CUDA_DSA'] = '1'
from transformers import AutoTokenizer, AutoModelForCausalLM
tokenizer = AutoTokenizer.from_pretrained("internlm/internlm2-math-plus-20b", trust_remote_code=True, cache_dir="/data/internlm-explore/models")
# Set `torch_dtype=torch.float16` to load model in float16, otherwise it will be loaded as float32 and might cause OOM Error.
model = AutoModelForCausalLM.from_pretrained("internlm/internlm2-math-plus-20b", trust_remote_code=True, torch_dtype=torch.float16, cache_dir="/data/internlm-explore/models").cuda()
model = model.eval()
response, history = model.chat(tokenizer, "若直线y=ax+b经过第一、二、三象限，求解a*b的符号", history=[], meta_instruction="")
print(response)
