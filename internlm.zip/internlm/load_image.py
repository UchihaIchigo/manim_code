import torch
from transformers import AutoModel, AutoTokenizer, AutoModelForCausalLM
import os


# torch.cuda.set_device(1)  # 选择第二个GPU
os.environ['CUDA_VISIBLE_DEVICES']='2' #此处选择你要用的GPU序号 0，1，2，3
os.environ['CUDA_LAUNCH_BLOCKING'] = '2' # 下面老是报错 shape 不一致
os.environ['TORCH_USE_CUDA_DSA'] = '2'
torch.set_grad_enabled(False)


ckpt_path = "internlm/internlm-xcomposer2-vl-7b"
tokenizer = AutoTokenizer.from_pretrained(ckpt_path, trust_remote_code=True, cache_dir="/data/internlm-explore/models")
# Set `torch_dtype=torch.float16` to load model in float16, otherwise it will be loaded as float32 and might cause OOM Error.
model = AutoModelForCausalLM.from_pretrained(ckpt_path, torch_dtype=torch.float32, trust_remote_code=True, cache_dir="/data/internlm-explore/models").cuda()
model = model.eval()

text = """<ImageHere>
图片是manim生成的视频最后一帧的截图。以下是我的manim 代码，
from manim import *
class run2(Scene):
    def construct(self):
        # 创建标题文本
        title1 = Text("已知一次函数y=kx+b的图像与直线y=2x+1平行，", font_size=14)
        title2 = Text("且与y=3x+1的纵坐标为-2,求k，b的值。", font_size=34)
        title_group = VGroup(title1, title2).arrange(DOWN, center=False).move_to(ORIGIN)
        # 播放标题显示动画
        self.play(Write(title_group))
        self.wait(2)
        self.play(FadeOut(title_group))



        # 第二幕：展示解析过程
        axes1 = Axes(
            x_range=[-6, 3, 1],
            y_range=[-8, 6, 1],
            x_length=7,
            y_length=6,
            axis_config={"include_numbers": True},
        )
        labels = axes1.get_axis_labels(x_label="x", y_label="y")
        # 画出两条一次函数的图像
        graph1 = axes1.plot(lambda x: 2 * x + 1, color=RED)
        graph2 = axes1.plot(lambda x: 3 * x + 1, color=BLUE)
        graph3 = axes1.plot(lambda x: 2 * x, color=YELLOW)
        graph_label1 = axes1.get_graph_label(graph1, label="y = 2x + 1", x_val=1, direction=UR)
        graph_label2 = axes1.get_graph_label(graph2, label="y = 3x + 1", x_val=3, direction=UR)
        graph_label3 = axes1.get_graph_label(graph3, label="y = 2x", x_val=3, direction=UR)
        point = Dot(axes1.coords_to_point(-1, -2), color=GREEN)
        points = VGroup(point)
        # 播放创建坐标轴、标签和图像的动画
        self.play(Create(axes1), Write(labels))
        self.play(Create(graph1), Write(graph_label1))
        self.play(Create(graph2), Write(graph_label2))
        self.play(Create(graph3), Write(graph_label3))
        self.play(Create(points))
        # 创建解释文本
        explanation = VGroup(
            Text("1.确定一次函数的形式", font_size=14),
            Text("2.应用平行线性质，斜率应该相等，即k=2", font_size=20),
            Text("3.确定函数的交点，代入y=3x+1=-2：", font_size=30),
            MathTex("3x+1=-2\\Rightarrow x=-1", font_size=10),
            Text("4.将点(-1,-2)代入平行线y=2x+b：", font_size=16),
            MathTex("2*(-1)+b=-2\\Rightarrow b=0", font_size=20),
        )

        # 逐步显示解释文本
        for step in explanation:
            self.play(Write(step))
            self.wait(2)
        self.wait(3)

以上是我的原始manim代码，对应上传的图片。由于我的代码生成的图片不美观，有以下一些需要改进的地方：
1.第一幕的标题文本需要保持居中，如VGroup().arrange(DOWN, center=False).move_to(ORIGIN)
2.修改Text和MathTex中的参数font_size的值，使整体文字比较美观，一般为font_size=24.
3.修改get_graph_label中的参数x_val的值，使生成的标签在视觉上不会产生重叠
4.第二幕中对于坐标系的生成，期望它在图中的位置为左半画布，因此可以修改方法Axes()的超参数，如Axes().scale(0.8).to_edge(LEFT, buff=0.9)
5.第二幕中对于解释文本的排版，期望它出现在右半画布中，可以修改explanation=VGroup()的超参数，如VGroup().arrange(DOWN, aligned_edge=LEFT).scale(0.7).to_edge(RIGHT, buff=1)
6.第二幕中修改Text和MathTex中的参数font_size的值，使整体文字比较美观，一般为font_size=24.
7.统一所有文本的大小

最后，请输出你修改后的manim代码，并且输出你在哪些地方做了修改，以及修改原因
        """
image = '/data/internlm-explore/4.png'
print(f"问题：{text}")
with torch.cuda.amp.autocast():
  response, _ = model.chat(tokenizer, query=text, image=image, history=[], do_sample=False)
print(response)
#The image features a quote by Oscar Wilde, "Live life with no excuses, travel with no regret,"
# set against a backdrop of a breathtaking sunset. The sky is painted in hues of pink and orange,
# creating a serene atmosphere. Two silhouetted figures stand on a cliff, overlooking the horizon.
# They appear to be hiking or exploring, embodying the essence of the quote.
# The overall scene conveys a sense of adventure and freedom, encouraging viewers to embrace life without hesitation or regrets.
