import torch
from transformers import AutoModel, AutoTokenizer, AutoModelForCausalLM
import os

# 设置 GPU 设备 ID，例如指定使用第 1 块 GPU（索引为 0）
device_id = 1
torch.cuda.set_device(device_id)

# 检查 CUDA 是否可用并清空缓存
if torch.cuda.is_available():
    print(f"Using GPU: {device_id}")
    torch.cuda.empty_cache()  # 清空缓存