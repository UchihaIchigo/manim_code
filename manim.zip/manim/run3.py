import json
import subprocess
from openai import OpenAI

# 设置 OpenAI 客户端
client = OpenAI(
    base_url='http://localhost:11434/v1',
    api_key='ollama',
)

def read_json_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)

# def generate_manim_code_from_problem_and_solution(math_problem, solution, model="gpt-4", attempt=0, max_retries=3):
#     try:
#         # 将题目和解题过程组合成一个提示
#         prompt = f"""根据下面的题目和对应解题过程,生成相应的Manim代码来展示这个解题过程中的数学函数图像和解题步骤。直接写manim代码,不需要解释别的。
#                     示例：
#                     题目: 求函数$f(x) = x^2 - 4x + 3$的顶点，并画出其图像。

#                     解题方案： Derive the Function: First, we find the derivative of $f(x)$, which is $f'(x) = 2x - 4$.Find the Zero of the Derivative: Setting $f'(x) = 0$, we solve for $x$ and get $x = 2$. 
#                     This means the function has an extremum at $x = 2$.Compute the $y$ Coordinate of the Vertex: Substituting $x = 2$ into the original function, we get $f(2) = 2^2 - 4*2 + 3 = -1$. Thus, the vertex is at $(2, -1)$.
#                     Determine the Type of the Vertex: Since the coefficient of the quadratic term is positive, we know this vertex represents the minimum point of the function, i.e., the lowest point on the graph.
                    
#                     Manim代码:from manim import *
#                             class SolveAndVisualizeFunction(Scene):
#                                 def construct(self):
#                                     self.show_solution_steps()
#                                     self.plot_function()

#                                 def show_solution_steps(self):
#                                     steps = VGroup(
#                                         Tex(r"1. Derive the function: $f'(x) = 2x - 4$",font_size=24),
#                                         Tex(r"2. Find the zero of the derivative: $x = 2$",font_size=24),
#                                         Tex(r"3. Compute the $y$ coordinate of the vertex: $f(2) = -1$",font_size=24),
#                                         Tex(r"4. Determine the type of the vertex: minimum point",font_size=24),
#                                     )
#                                     steps.arrange(DOWN, aligned_edge=LEFT)
#                                     for step in steps:
#                                         self.play(Write(step))
#                                         self.wait(1)
#                                     self.play(*[FadeOut(step) for step in steps])

#                                 def plot_function(self):
#                                     axes = Axes(
#                                         x_range=[-1, 5],
#                                         y_range=[-2, 6],
#                                     )
#                                     quadratic_graph = axes.plot(lambda x: x**2 - 4*x + 3, color=GREEN)
#                                     graph_label = axes.get_graph_label(quadratic_graph, label='f(x)=x^2-4x+3')
                                    
#                                     vertex_dot = Dot(axes.c2p(2, -1), color=RED)
#                                     vertex_label = MathTex("(2, -1)").next_to(vertex_dot, DOWN)
                                    
#                                     self.play(Create(axes), Create(quadratic_graph), Write(graph_label))
#                                     self.play(FadeIn(vertex_dot), Write(vertex_label))
#                                     self.wait(2)

#                     题目：{math_problem}

#                     解题方案：{solution}

#                     Manim代码:
#                     """
#         response = client.chat.completions.create(
#             model="codellama",
#             messages=[
#                 {"role": "user", "content": prompt}
#             ]
#         )
#         # Extracting only the Manim code from the response
#         full_response = response.choices[0].message.content
#         code_start = full_response.find("from manim import *")  # Find the start of the code
#         manim_code = full_response[code_start:] if code_start != -1 else "Manim code not found."

#         return manim_code
#     except Exception as e:
#         print(f"出错: {e}")
#         return "Error generating code"

def generate_manim_code_from_problem_and_solution(math_problem, solution, model="gpt-4", attempt=0, max_retries=3):
    try:
        # 将题目和解题过程组合成一个提示
        prompt = f"""根据下面的题目和对应解题过程,生成相应的Manim代码来展示这个解题过程中的数学函数图像和解题步骤。直接写manim代码,不需要解释别的。
                    示例：
                    题目: 求函数$f(x) = x^2 - 4x + 3$的顶点，并画出其图像。

                    解题方案： Derive the Function: First, we find the derivative of $f(x)$, which is $f'(x) = 2x - 4$.Find the Zero of the Derivative: Setting $f'(x) = 0$, we solve for $x$ and get $x = 2$. 
                    This means the function has an extremum at $x = 2$.Compute the $y$ Coordinate of the Vertex: Substituting $x = 2$ into the original function, we get $f(2) = 2^2 - 4*2 + 3 = -1$. Thus, the vertex is at $(2, -1)$.
                    Determine the Type of the Vertex: Since the coefficient of the quadratic term is positive, we know this vertex represents the minimum point of the function, i.e., the lowest point on the graph.
                    
                    Manim代码:from manim import *
                            class SolveAndVisualizeFunction(Scene):
                                def construct(self):
                                    self.show_solution_steps()
                                    self.plot_function()

                                def show_solution_steps(self):
                                    steps = VGroup(
                                        Tex(r"1. Derive the function: $f'(x) = 2x - 4$",font_size=24),
                                        Tex(r"2. Find the zero of the derivative: $x = 2$",font_size=24),
                                        Tex(r"3. Compute the $y$ coordinate of the vertex: $f(2) = -1$",font_size=24),
                                        Tex(r"4. Determine the type of the vertex: minimum point",font_size=24),
                                    )
                                    steps.arrange(DOWN, aligned_edge=LEFT)
                                    for step in steps:
                                        self.play(Write(step))
                                        self.wait(1)
                                    self.play(*[FadeOut(step) for step in steps])

                                def plot_function(self):
                                    axes = Axes(
                                        x_range=[-1, 5],
                                        y_range=[-2, 6],
                                    )
                                    quadratic_graph = axes.plot(lambda x: x**2 - 4*x + 3, color=GREEN)
                                    graph_label = axes.get_graph_label(quadratic_graph, label='f(x)=x^2-4x+3')
                                    
                                    vertex_dot = Dot(axes.c2p(2, -1), color=RED)
                                    vertex_label = MathTex("(2, -1)").next_to(vertex_dot, DOWN)
                                    
                                    self.play(Create(axes), Create(quadratic_graph), Write(graph_label))
                                    self.play(FadeIn(vertex_dot), Write(vertex_label))
                                    self.wait(2)

                    题目：{math_problem}

                    解题方案：{solution}

                    Manim代码:
                    """
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        # Extracting only the Manim code from the response
        full_response = response.choices[0].message.content
        code_start = full_response.find("from manim import *")  # Find the start of the code
        manim_code = full_response[code_start:] if code_start != -1 else "Manim code not found."

        return manim_code
    except Exception as e:
        print(f"出错: {e}")
        return "Error generating code"


def write_code_to_file(code, file_name):
    with open(file_name, "w") as file:
        file.write(code)

def run_manim(file_name):
    try:
        subprocess.run(["manim", "-p", "-ql", file_name], check=True)
        return True  # 成功生成视频
    except subprocess.CalledProcessError:
        return False  # 生成视频失败

def process_questions_from_json(file_path):
    data = read_json_file(file_path)
    max_attempts = 1

    for item in data:
        math_problem = item['question']
        solution = ' '.join(item['solution'])  # 将解决方案列表转换为字符串
        success = False
        attempt = 0

        while not success and attempt < max_attempts:
            attempt += 1
            # print(f"Attempt {attempt} for question ID {item['id']}")

            manim_code = generate_manim_code_from_problem_and_solution(math_problem, solution)
            file_name = f"generated_scene_{item['id']}.py"
            write_code_to_file(manim_code, file_name)

        #     success = run_manim(file_name)

        #     if success:
        #         print(f"Video for question ID {item['id']} generated successfully.")
        #     else:
        #         print(f"Attempt {attempt}: Failed to generate video for question ID {item['id']}. Retrying...")

        # if not success:
        #     print(f"Failed to generate video after {max_attempts} attempts for question ID {item['id']}.")


if __name__ == "__main__":
    json_file_path = '30.json'
    process_questions_from_json(json_file_path)
