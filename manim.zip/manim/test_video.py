import os
from moviepy.editor import *

from llama_index.core.indices.multi_modal.base import MultiModalVectorStoreIndex
from llama_index.core import SimpleDirectoryReader, StorageContext

from llama_index.core import SimpleDirectoryReader, StorageContext
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import (
    SimpleDirectoryReader,
)

from llama_index.core.response.notebook_utils import display_source_node
from llama_index.core.schema import ImageNode

from llama_index.multi_modal_llms.openai import OpenAIMultiModal
import openai



# 设置API密钥
# openai.api_key = "sk-8XGqiRc9787Q19pnlyrGu5L6Gm7z81fIv2Rv1JWlmmCs6GkY"
OPENAI_API_TOKEN = "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"  # 请替换为你的实际 API 密钥
openai.api_key = OPENAI_API_TOKEN
openai.api_base = "https://api.chatanywhere.tech/v1"

def video_to_images(video_path, output_folder):
    """
    Convert a video to a sequence of images and save them to the output folder.

    Parameters:
    video_path (str): The path to the video file.
    output_folder (str): The path to the folder to save the images to.

    """
    clip = VideoFileClip(video_path)
    clip.write_images_sequence(
        os.path.join(output_folder, "frame%04d.png"), fps=1  # configure this for controlling frame rate.
    )

# video_path = '/tmp/pycharm_project_917/media/videos/example/480p15/run2.mp4'
# output_folder = '/tmp/pycharm_project_917/media/videos/example/480p15/image'
video_path = 'D:\DeepL_code\manim_video\Main.mp4'
output_folder = 'D:\DeepL_code\manim_video\image'
video_to_images(video_path, output_folder)


image_store = LanceDBVectorStore(uri="lancedb", table_name="image_collection")
storage_context = StorageContext.from_defaults(
    image_store=image_store
)

# Create the MultiModal index
documents = SimpleDirectoryReader(output_folder).load_data()

index = MultiModalVectorStoreIndex.from_documents(
    documents,
    storage_context=storage_context,
)
#根据相似性分数从 vectordb 中获取最相关的前 5 个
retriever_engine = index.as_retriever(
    similarity_top_k=50, image_similarity_top_k=50
)
def retrieve(retriever_engine, query_str):
    retrieval_results = retriever_engine.retrieve(query_str)

    retrieved_image = []
    retrieved_text = []
    for res_node in retrieval_results:
        if isinstance(res_node.node, ImageNode):
            retrieved_image.append(res_node.node.metadata["file_path"])
        else:
            display_source_node(res_node, source_length=200)
            retrieved_text.append(res_node.text)

    return retrieved_image, retrieved_text

query_str = """
输出最不美观的只含文字的或含有图表图片的路径\n

"""
img, txt = retrieve(retriever_engine=retriever_engine, query_str=query_str)
image_documents = SimpleDirectoryReader(
    input_dir=output_folder, input_files=img
).load_data()
context_str = "".join(txt)
# plot_images(img)
for i in range(len(img)):
    print(img[i])


qa_tmpl_str = (
    """
 Given the provided information, including relevant images and retrieved context from the video, \
 accurately and precisely answer the query without any additional prior knowledge.\n"
    "Please ensure honesty and responsibility, refraining from any racist or sexist remarks.\n"
    "按照相关性排列图片数据\n
检测图片的特殊性\n
输出有代表性的出错图片\n
最多不超过5个"
    "---------------------\n"
    "Context: {context_str}\n"
    "Metadata for video: {metadata_str} \n"
    "---------------------\n"
    "Query: {query_str}\n"
    "Answer: "
"""
)


openai_mm_llm = OpenAIMultiModal(
    model="gpt-4-vision-preview", api_key=OPENAI_API_TOKEN, max_new_tokens=1500
)

print(1)
response_1 = openai_mm_llm.complete(
    prompt=qa_tmpl_str.format(
        context_str=context_str, query_str=query_str, metadata_str=img
    ),
    image_documents=image_documents,
)

print(response_1.text)